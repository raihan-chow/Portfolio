$(document).ready(function(){

// console.log();

// Team Carousel
var owlTeam = $('.meet_the_team_carousel');
owlTeam.owlCarousel({
	items:4,
	margin:30,
	nav:false,
	dots:false,
	autoplay:false,
	autoplayHoverPause:false,
	loop:false,
	autoWidth: false,
	//mouseDrag:false,
	responsive: {
		0:{
            items:1,
            nav:true
        },
        480:{
            items:2,
        },
        640: {
        	items:3,
        },
        992:{
            items:4,
        }
	}
});

// Go to the previous item
$('.arrow_prev').click(function() {
    // With optional speed parameter
    // Parameters has to be in square bracket '[]'
    owlTeam.trigger('prev.owl.carousel');
});

$('.arrow_next').click(function() {
    owlTeam.trigger('next.owl.carousel');
})


// testimonial_area
var owlTest = $('.testimonial_content');
owlTest.owlCarousel({
	items:1,
	//margin:30,
	nav:false,
	dots:false,
	autoplay:true,
	autoplayHoverPause:true,
	loop:true,
	animateIn: 'backSlideIn',
	animateOut: 'backSlideOut',
	//autoWidth: false,
	//mouseDrag:false,
});



$('.single_progress_bar').hover(function(){
	$(this).find('.progress').addClass('anim_progress').find('.progress-bar').addClass('active');
},
	function(){
		$(this).find('.progress').removeClass('anim_progress').find('.progress-bar').removeClass('active');
	}
);


$('input:not([type="submit"]), textarea').focus(function(){

	var inputVal = $(this).attr('placeholder');
	$(this).attr('placeholder', "");
	$(this).blur(function(){
		$(this).attr('placeholder', inputVal);
	});	
});







if($(document.body).width() > 768){
	$('#para_element').zlayer(
	    [
	        {
	            layer:'.parallax0',
	            mass:15,
	            //confine:'y'
	        },
	        {
	            layer:'.parallax1',
	            mass:15,
	            //confine:'y'
	        },
	        {
	            layer:'.parallax2',
	            mass:8,
	            force:'push'
	        },
	        {
	            layer:'.parallax3',
	            mass:10,
	            force:'pull'
	        },
	        {
	            layer:'.parallax4',
	            mass:15,
	            force:'pull'
	        },
	        {
	            layer:'.parallax5',
	            mass:15,
	            force:'pull'
	        },
	        {
	            layer:'.parallax6',
	            mass:15,
	            force:'pull'
	        },
	        {
	            layer:'.parallax7',
	            mass:15,
	            force:'push'
	        },
	        {
	            layer:'.parallax8',
	            mass:15,
	            force:'pull'
	        },
	        {
	            layer:'.parallax9',
	            mass:15,
	            force:'pull'
	        },
	        {
	            layer:'.parallax10',
	            mass:15,
	            force:'pull'
	        },
	    ],{
	        repositionTransition:'all 2.5s ease-in'
	    }
	);

};


	//$('#nav').localScroll(800);
	
	//.parallax(xPosition, speedFactor, outerHeight) options:
	//xPosition - Horizontal position of the element
	//inertia - speed to move relative to vertical scroll. Example: 0.1 is one tenth the speed of scrolling, 2 is twice the speed of scrolling
	//outerHeight (true/false) - Whether or not jQuery should use it's outerHeight option to determine when a section is in the viewport
	if($(document.body).width() > 767){
		$('.services_area').parallax("50%", 0.2, true);
		$('.fun_facts_area').parallax("50%", 0.2);
		$('.skill_area').parallax("50%", 0.2);
		$('.testimonial_area').parallax("50%", 0.2);
		$('.contact_us_area').parallax("50%", 0.2);
	};
	






        


// Hover dir

$('.thumbnail_container > li.thumbnail_item').each( function() { $(this).hoverdir(); } );




 // Waypoints
 $('.fun_facts_area').waypoint(function() {
  // Counter
   $('.counter').counter({});

}); 

 $('.skill_area').waypoint(function() {
 	$('.single_progress_bar').on("changeState", function(e){
 		var newVal = $(this).find('.progress-bar').attr('aria-valuenow');
 		$(this).find('.progress-bar').css({'width' : + newVal + '%'});
 	});

 	$('.single_progress_bar').trigger("changeState");
   
});




/*Nice scroll*/
 // $("body").niceScroll({
 // 	cursorcolor: "#0EB493",
 // 	 cursorwidth: "10px",
 // 	 cursorborder: "1px solid #0EB493",
 // 	 cursorborderradius: "0px",
 // 	 zindex: 99,
 // 	 scrollspeed: 60,
 // 	 mousescrollstep: 40,
 // 	 autohidemode: false,
 // 	 cursorminheight: 100,
 // });


if($(document.body).width() > 767){
	/*wow animate*/
	new WOW().init({
		offset: 200
	});
};



var winHeight = $(window).height();
var scrollPos;

$(window).scroll(function(){

	scrollPos = $(window).scrollTop();
	
	if(winHeight + scrollPos == winHeight){

	//$('.header_top').animateCSS("flipInX", {delay: 200,});

	$('body').find('.wow').removeClass('animated');
	new WOW().init({
		offset: 300,
	});
	
};

});



//Slicknav
$('#nav_menu').slicknav({
	prependTo:'div.main_menu_area',
});



 // tubular video
 if (!!$.prototype.tubular)
 $('.video_promo').tubular({ 
 	//videoId: '_XI0ODNPqk4',
 	ratio: 16/9,
 	videoId: 'TCsyJM3E_qg', 
 	//videoId: '6ak3_iyyamk', 
 	start: 10,
 	repeat: false,
 	mute: false 
 });




// Google map
new Maplace({
	map_div: '#gmap-styled',
    show_markers: true,
    start: 1,
    //styles: styles,
    //type: 'polygon',
    locations: [{
        lat: 23.7484948, 
        lon: 90.4224101,
    }],
    map_options: {
	    mapTypeId: google.maps.MapTypeId.ROADMAP,
	    zoom: 15,
	    scrollwheel: false,
	    backgroundColor: "#2A2A2A"
	},
	styles: {
	        'Greyscale': [{              
	            featureType: 'all',
	            stylers: [
	                { saturation: -100 },
	                { gamma: 0.50 }
	            ]
	        }],
	        'Night': [{"featureType":"all","elementType":"all","stylers":[{"invert_lightness":true},{"saturation":10},{"lightness":30},{"gamma":0.6},{"hue":"#1A544B"}]}]
	    }
	
    
}).Load(); 










// jssor slider

var _CaptionTransitions = [];

            _CaptionTransitions["B-*|B"] = {$Duration:900,y:-0.7,$Rotate:0.5,$Easing:{$Top:$JssorEasing$.$EaseInCubic,$Opacity:$JssorEasing$.$EaseInQuad,$Rotate:$JssorEasing$.$EaseInBack},$Opacity:2,$During:{$Top:[0.2,0.8]}};
            _CaptionTransitions["L"] = { $Duration: 900, $FlyDirection: 1, $Easing: { $Left: $JssorEasing$.$EaseInOutSine }, $ScaleHorizontal: 0.6, $Opacity: 2 };
            _CaptionTransitions["R"] = { $Duration: 900, $FlyDirection: 2, $Easing: { $Left: $JssorEasing$.$EaseInOutSine }, $ScaleHorizontal: 0.6, $Opacity: 2 };
            _CaptionTransitions["T"] = { $Duration: 900, $FlyDirection: 4, $Easing: { $Top: $JssorEasing$.$EaseInOutSine }, $ScaleVertical: 0.6, $Opacity: 2 };
            _CaptionTransitions["B"] = { $Duration: 900, $FlyDirection: 8, $Easing: { $Top: $JssorEasing$.$EaseInOutSine }, $ScaleVertical: 0.6, $Opacity: 2 };
            _CaptionTransitions["ZMF|10"] = { $Duration: 900, $Zoom: 11, $Easing: { $Zoom: $JssorEasing$.$EaseOutQuad, $Opacity: $JssorEasing$.$EaseLinear }, $Opacity: 2 };
            _CaptionTransitions["RTT|10"] = { $Duration: 900, $Zoom: 11, $Rotate: 1, $Easing: { $Zoom: $JssorEasing$.$EaseOutQuad, $Opacity: $JssorEasing$.$EaseLinear, $Rotate: $JssorEasing$.$EaseInExpo }, $Opacity: 2, $Round: { $Rotate: 0.8} };
            _CaptionTransitions["RTT|2"] = { $Duration: 900, $Zoom: 3, $Rotate: 1, $Easing: { $Zoom: $JssorEasing$.$EaseInQuad, $Opacity: $JssorEasing$.$EaseLinear, $Rotate: $JssorEasing$.$EaseInQuad }, $Opacity: 2, $Round: { $Rotate: 0.5} };
            _CaptionTransitions["RTTL|BR"] = { $Duration: 900, $Zoom: 11, $Rotate: 1, $FlyDirection: 10, $Easing: { $Left: $JssorEasing$.$EaseInCubic, $Top: $JssorEasing$.$EaseInCubic, $Zoom: $JssorEasing$.$EaseInCubic, $Opacity: $JssorEasing$.$EaseLinear, $Rotate: $JssorEasing$.$EaseInCubic }, $ScaleHorizontal: 0.6, $ScaleVertical: 0.6, $Opacity: 2, $Round: { $Rotate: 0.8} };
            _CaptionTransitions["CLIP|LR"] = { $Duration: 900, $Clip: 15, $Easing: { $Clip: $JssorEasing$.$EaseInOutCubic }, $Opacity: 2 };
            _CaptionTransitions["MCLIP|L"] = { $Duration: 900, $Clip: 1, $Move: true, $Easing: { $Clip: $JssorEasing$.$EaseInOutCubic} };
            _CaptionTransitions["MCLIP|R"] = { $Duration: 900, $Clip: 2, $Move: true, $Easing: { $Clip: $JssorEasing$.$EaseInOutCubic} };

            var options = {
                $FillMode: 2,                                       //[Optional] The way to fill image in slide, 0 stretch, 1 contain (keep aspect ratio and put all inside slide), 2 cover (keep aspect ratio and cover whole slide), 4 actuall size, default value is 0
                $AutoPlay: true,                                    //[Optional] Whether to auto play, to enable slideshow, this option must be set to true, default value is false
                $AutoPlayInterval: 4000,                            //[Optional] Interval (in milliseconds) to go for next slide since the previous stopped if the slider is auto playing, default value is 3000
                $PauseOnHover: 1,                                   //[Optional] Whether to pause when mouse over if a slider is auto playing, 0 no pause, 1 pause for desktop, 2 pause for touch device, 3 pause for desktop and touch device, default value is 1

                $ArrowKeyNavigation: true,   			            //[Optional] Allows keyboard (arrow key) navigation or not, default value is false
                $SlideEasing: $JssorEasing$.$EaseOutQuint,          //[Optional] Specifies easing for right to left animation, default value is $JssorEasing$.$EaseOutQuad
                $SlideDuration: 1200,                                //[Optional] Specifies default duration (swipe) for slide in milliseconds, default value is 500
                $MinDragOffsetToSlide: 20,                          //[Optional] Minimum drag offset to trigger slide , default value is 20
                //$SlideWidth: 600,                                 //[Optional] Width of every slide in pixels, default value is width of 'slides' container
                //$SlideHeight: 300,                                //[Optional] Height of every slide in pixels, default value is height of 'slides' container
                $SlideSpacing: 0, 					                //[Optional] Space between each slide in pixels, default value is 0
                $DisplayPieces: 1,                                  //[Optional] Number of pieces to display (the slideshow would be disabled if the value is set to greater than 1), the default value is 1
                $ParkingPosition: 0,                                //[Optional] The offset position to park slide (this options applys only when slideshow disabled), default value is 0.
                $UISearchMode: 1,                                   //[Optional] The way (0 parellel, 1 recursive, default value is 1) to search UI components (slides container, loading screen, navigator container, arrow navigator container, thumbnail navigator container etc).
                $PlayOrientation: 1,                                //[Optional] Orientation to play slide (for auto play, navigation), 1 horizental, 2 vertical, default value is 1
                $DragOrientation: 1,                                //[Optional] Orientation to drag slide, 0 no drag, 1 horizental, 2 vertical, 3 either, default value is 1 (Note that the $DragOrientation should be the same as $PlayOrientation when $DisplayPieces is greater than 1, or parking position is not 0)

                $CaptionSliderOptions: {                            //[Optional] Options which specifies how to animate caption
                    $Class: $JssorCaptionSlider$,                   //[Required] Class to create instance to animate caption
                    $CaptionTransitions: _CaptionTransitions,       //[Required] An array of caption transitions to play caption, see caption transition section at jssor slideshow transition builder
                    $PlayInMode: 1,                                 //[Optional] 0 None (no play), 1 Chain (goes after main slide), 3 Chain Flatten (goes after main slide and flatten all caption animations), default value is 1
                    $PlayOutMode: 3                                 //[Optional] 0 None (no play), 1 Chain (goes before main slide), 3 Chain Flatten (goes before main slide and flatten all caption animations), default value is 1
                },

                $BulletNavigatorOptions: {                                //[Optional] Options to specify and enable navigator or not
                    $Class: $JssorBulletNavigator$,                       //[Required] Class to create navigator instance
                    $ChanceToShow: 2,                               //[Required] 0 Never, 1 Mouse Over, 2 Always
                    $AutoCenter: 1,                                 //[Optional] Auto center navigator in parent container, 0 None, 1 Horizontal, 2 Vertical, 3 Both, default value is 0
                    $Steps: 1,                                      //[Optional] Steps to go for each navigation request, default value is 1
                    $Lanes: 1,                                      //[Optional] Specify lanes to arrange items, default value is 1
                    $SpacingX: 8,                                   //[Optional] Horizontal space between each item in pixel, default value is 0
                    $SpacingY: 8,                                   //[Optional] Vertical space between each item in pixel, default value is 0
                    $Orientation: 1                                 //[Optional] The orientation of the navigator, 1 horizontal, 2 vertical, default value is 1
                },

                $ArrowNavigatorOptions: {                       //[Optional] Options to specify and enable arrow navigator or not
                    $Class: $JssorArrowNavigator$,              //[Requried] Class to create arrow navigator instance
                    $ChanceToShow: 1,                               //[Required] 0 Never, 1 Mouse Over, 2 Always
                    $AutoCenter: 2,                                 //[Optional] Auto center arrows in parent container, 0 No, 1 Horizontal, 2 Vertical, 3 Both, default value is 0
                    $Steps: 1                                       //[Optional] Steps to go for each navigation request, default value is 1
                }
            };

            var jssor_slider1 = new $JssorSlider$("slider1_container", options);

            //responsive code begin
            //you can remove responsive code if you don't want the slider scales while window resizes
            function ScaleSlider() {
                var bodyWidth = document.body.clientWidth;
                if (bodyWidth)
                    jssor_slider1.$SetScaleWidth(Math.min(bodyWidth, 1920));
                else
                    window.setTimeout(ScaleSlider, 30);
            }

            ScaleSlider();

            if (!navigator.userAgent.match(/(iPhone|iPod|iPad|BlackBerry|IEMobile)/)) {
                $(window).bind('resize', ScaleSlider);
            }


            //if (navigator.userAgent.match(/(iPhone|iPod|iPad)/)) {
            //    $(window).bind("orientationchange", ScaleSlider);
            //}
            //responsive code end


}); //document ready














