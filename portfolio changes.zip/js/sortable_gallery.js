
var thumbnailPadding = 20;



var thumbnailSpacing = 0;

$(document).ready(function(){
	
	$('a.sortLink').on('click',function(e){
		e.preventDefault();
		$('a.sortLink').removeClass('selected');
		$(this).addClass('selected');
		var keyword = $(this).attr('data-keyword');
		sortThumbnails(keyword);

		itemPadding();
	});
	
	$('.gallery .sorting').css('margin-bottom',window.thumbnailSpacing+'px');
	$('.thumbnail_container li.thumbnail_item').addClass('showMe').addClass('fancybox').attr('rel','group');
	
	positionThumbnails();

	itemPadding();
	
	setInterval('checkViewport()',750);

	$(window).resize(function(){
		positionThumbnails();
		itemPadding();
	});


});

function checkViewport(){
	var photosWidth = $('.photos').width();
	var thumbnailContainerWidth = $('.thumbnail_container').width();
	var thumbnailWidth = $('.thumbnail_container li.thumbnail_item:first-child').outerWidth();
	
	if( photosWidth < thumbnailContainerWidth){
		positionThumbnails();
	}
	
	if( (photosWidth - thumbnailWidth) > thumbnailContainerWidth){
		positionThumbnails();
	}
	/*debug*/ //$('.debug-size').html('photosWidth = '+photosWidth+' thumbnailContainerWidth = '+thumbnailContainerWidth);
	
}


function sortThumbnails(keyword){
	$('.thumbnail_container li.thumbnail_item').each(function() {
        var thumbnailKeywords = $(this).attr('data-keywords');
		
		if(keyword == 'all'){
			$(this).addClass('showMe').removeClass('hideMe').attr('rel','group');
		}else{
			if(thumbnailKeywords.indexOf(keyword) != -1){
				$(this).addClass('showMe').removeClass('hideMe').attr('rel','group');
			}else{
				$(this).addClass('hideMe').removeClass('showMe').attr('rel','none');
			}
		}
    });
	
	positionThumbnails();
	
}



var max_C;
var thumbnailHeight;

function positionThumbnails(){
	//$('.debug-remainder').html('');
	
	$('.thumbnail_container li.thumbnail_item.hideMe').animate({opacity:0},400,function(){
		$(this).css({'display':'none','top':'0px','left':'0px'});
	});
	
	var containerWidth = $('.photos').width();
	var thumbnail_R = 0;
	var thumbnail_C = 0;
	var thumbnailWidth = $('li.thumbnail_item:first-child').outerWidth() + window.thumbnailSpacing;
		thumbnailHeight = $('li.thumbnail_item:first-child').outerHeight() + window.thumbnailSpacing;
	max_C = Math.floor( containerWidth / thumbnailWidth);
	
	$('.thumbnail_container li.thumbnail_item.showMe').each(function(index) {
		var remainder = (index%max_C)/100;
		var maxIndex = 0;
		//$('.debug-remainder').append(remainder+' - ');
		if(remainder==0){
			if(index !=0){
				thumbnail_R += thumbnailHeight;
			}
			thumbnail_C = 0;
		}else{
			thumbnail_C += thumbnailWidth;
		}
        
		$(this).css('display','block').animate({
			'opacity':1,
			'top': thumbnail_R+'px',
			'left': thumbnail_C+'px'
		}, 500);
		
		var newWidth = max_C * thumbnailWidth;
		var newHeight = thumbnail_R + thumbnailHeight;
		$('.thumbnail_container').css({'width':newWidth+'px','height':newHeight+'px'});

    });
	
	//detectFancyboxLinks();
	
	var sortingWidth = $('.thumbnail_container').width() / thumbnailWidth;
	var newWidth = sortingWidth * thumbnailWidth - window.thumbnailSpacing;
	$('.sorting').css('width',newWidth+'px');

}


function itemPadding(){

		$('.thumbnail_container li.thumbnail_item.showMe').css({
			'padding-right': thumbnailPadding+'px','padding-bottom': thumbnailPadding+'px', 'height' : + thumbnailHeight + 'px'});

		var totalCount = $('.thumbnail_container li.thumbnail_item.showMe').length;
		var itemCount = max_C;

		$('.thumbnail_container li.thumbnail_item.showMe').each(function(i){
			
			if(itemCount*i > 0 && itemCount*i <= totalCount){
				$('.thumbnail_container li.thumbnail_item.showMe').eq((itemCount*i)-1).css({'padding':'0px','margin':'0px', 'height': + (thumbnailHeight-thumbnailPadding)+'px'});
				
			}
			
		});
	}


// function detectFancyboxLinks(){
	
// 	$('a.fancybox').unbind('click.fb');
// 	if( $(window).width() < 550){
// 		$('.thumbnail_container li.thumbnail_item').removeClass('fancybox').attr('target','_blank');
		
// 	}else{
// 		$('.thumbnail_container li.thumbnail_item').removeAttr('target');
// 	}
	
// 	$('a.fancybox[rel="group"]').fancybox({
// 		'transitionIn' : 'elastic',
// 		'transitionOut' : 'elastic',
// 		'titlePosition' : 'over',
// 		'speedIn' : 500,
// 		'overlayColor' : '#000',
// 		'padding' : 0,
// 		'overlayOpacity' : .75
		
// 	});
	
// }

// $(document).ready(function(){

// 	var thumbnailPadding = 10;
	

// 	$('a.sortLink').click(function(){

// 		$('.thumbnail_container li.thumbnail_item.showMe a').css({
// 			'padding-right': thumbnailPadding+'px',
// 			'display':'block',
// 		});

// 		var totalCount = $('.thumbnail_container li.thumbnail_item.showMe').length;
// 		var itemCount = 4;


// 		$('.thumbnail_container li.thumbnail_item.showMe').each(function(i){
			
// 			if(itemCount*i > 0 && itemCount*i <= totalCount){
// 				$('.thumbnail_container li.thumbnail_item.showMe').eq((itemCount*i)-1).find('a').css({'padding-right': '0px'});
// 			}
			
// 		});
		
		
// 		// $('.thumbnail_container li.thumbnail_item.showMe').eq((4*i)-1).siblings().find('a').css({
// 		// 	'padding-right': thumbnailPadding+'px',
// 		// 	'display':'block',
// 		// });	

		
// 		// $('.thumbnail_container li.thumbnail_item.showMe:nth-child(4n)').find('a').css({'padding-right': '0px'});

// 		// $('.thumbnail_container li.thumbnail_item.showMe:nth-child(4n)').siblings().find('a').css({
// 		// 	'padding-right': thumbnailPadding+'px',
// 		// 	'display':'block',
// 		// });
		

// 	});
// });