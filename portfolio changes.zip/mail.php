<?php 

$name = $_POST['f_name'];
$project = $_POST['project'];
$email = $_POST['email'];
$coments = $_POST['coments'];
$formcontent="From: $name \n Project: $project \n Email: $email \n Coments: $coments";
$recipient = "raihan.delta@gmail.com";
$subject = "Contact From visitor";
$mailheader = "From: $email \r\n";

mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
if(mail){

header('Location: index.html');

}else{ echo "Email failed to send";}


?>
 
